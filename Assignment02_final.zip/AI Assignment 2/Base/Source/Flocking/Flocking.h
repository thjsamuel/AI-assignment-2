//#ifndef FLOCKING_H
//#define FLOCKING_H
//#include "Vector3.h"
//
//class Flocking : public CBaseGameEntity // A manager class for flocking
//{
//public:
//    Flocking(vector<entity_type> entity_list);
//    ~Flocking();
//    vector<entity_type> entities; // The list of entities in the flock
//    vector< // This are the positions where the flock members are supposed to go to achieve cohesion, aka their destination
//};
//
//#endif