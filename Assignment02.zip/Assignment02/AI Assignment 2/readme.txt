Actors can send messages to each other,
actors change state upon receiving specific messages