//#include "StateFactory.h"
//
//StateFactory::StateFactory()
//{
//
//}
//
//StateFactory::~StateFactory()
//{
//
//}
//
//void StateFactory::init()
//{
//	if (itself == nullptr)
//		itself = new StateFactory();
//}